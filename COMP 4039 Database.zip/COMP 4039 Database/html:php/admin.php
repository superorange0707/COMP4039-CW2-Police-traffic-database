<html>
<head>
    <title>INTERNAL POLICE SYSTEM</title>
    <link rel="stylesheet" href="mvp.css">
</head>
<body>
<div align="right" style="color:black;">
    <font size=5>Identity：Administrator </font>
</div>
<br>
<div align="right" style="color:red;">
    <a href="change_password_ad.php" style="color:red;"><font size=5>change password </font></a>
</div>
<br>
<div align="right" style="color:red;">
    <a href="login.php" style="color:red;"><font size=5>log out </font></a>
</div>
<main>
    <h1>INTERNAL POLICE SYSTEM</h1>


    <a href="searchpeople_admin.php"><font size=5>People Query</font></a>
    <br>
    <br>
    <a href="searchcar_admin.php"><font size=5>Vehicle Query</font></a>
    <br>
    <br>
    <a href="Insertverify_admin.php"><font size=5>Add Vehicle information</font></a>
    <br>
    <br>
    <a href="Report_amin.php"><font size=5>Reporting</font></a>
    <br>
    <br>
    <a href="new_account.php"><font size=5>Create police officer accounts</font></a>
    <br>
    <br>
    <a href="add_fine.php"><font size=5>Add fines</font></a>


</main>
</body>
</html>

