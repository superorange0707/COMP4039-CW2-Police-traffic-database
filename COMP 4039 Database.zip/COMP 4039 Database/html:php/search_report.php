<html>
<head>
    <title>Search Report</title>
    <link rel="stylesheet" href="mvp.css">
</head>
<body>
<main>
    <h1>Search Report</h1>
    <h2>Report ID</u></h2>

    <form  method="post">
        Incident ID: <input type="text" name="incident_id">
        <input type="submit" value="Search">
    </form>

    <?php
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $servername = "mysql.cs.nott.ac.uk";
    $username = "psxjj4_psxjj4_1";
    $password = "WKXLHX";
    $dbname = "psxjj4_psxjj4_1"; 

    if (isset($_POST['incident_id']))
    {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
        }
        $incident_id = $_POST['incident_id'];
        $sql = "SELECT * FROM Incident WHERE Incident_ID = '$incident_id';" ;
        $result = mysqli_query($conn, $sql);

    //check the incident in the system
        if (mysqli_num_rows($result) <= 0) {
            echo "<script>alert('There is no incident with this number in the system')</script>";
        }
//        join four forms to get information
        else{
            $union = "SELECT * FROM (Incident LEfT JOIN Vehicle on Incident.Vehicle_ID = Vehicle.Vehicle_ID LEfT JOIN People on Incident.People_ID = People.People_ID LEfT JOIN Offence on Incident.Offence_ID = Offence.Offence_ID ) WHERE Incident_ID = '$incident_id';" ;
            $result_info = mysqli_query($conn, $union);
            $row = mysqli_fetch_assoc($result_info);
            $vehicle_licence = $row["Vehicle_licence"];
            $people = $row["People_name"];
            $time = $row["Incident_Date"];
            $report = $row["Incident_Report"];
            $offence = $row["Offence_description"];
            $People_address = $row["People_address"];
            $People_licence = $row["People_licence"];
            echo "Vehicle_licence:",$vehicle_licence;
            echo '<br>';
            echo "People_name:",$people;
            echo '<br>';
            echo "People_address:",$People_address;
            echo '<br>';
            echo "People_licence:",$People_licence;
            echo '<br>';
            echo "Incident time:",$time;
            echo '<br>';
            echo "Incident report:",$report;
            echo '<br>';
            echo "Offence Description:",$offence;
            echo '<br>';
        }
        mysqli_close($conn);
    }
    ?>
</main>
<footer><a href="index.php">Back to main page</a></footer>
</body>
</html>




