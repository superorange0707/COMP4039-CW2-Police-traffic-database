<html>
<head>
    <title>INTERNAL POLICE SYSTEM</title>
    <link rel="stylesheet" href="mvp.css">
</head>
<body>
<div align="right" style="color:black;">
    <font size=5>Identity：Police Officer </font>
</div>
<div align="right" style="color:red;">
    <a href="change_password.php" style="color:red;"><font size=5>change password </font></a>
</div>
<div align="right" style="color:red;">
    <a href="login.php" style="color:red;"><font size=5>log out </font></a>
</div>
<main>
    <h1>INTERNAL POLICE SYSTEM</h1>


    <a href="searchpeople.php"><font size=5>People Query</font></a>
    <br>
    <br>
    <a href="searchcar.php"><font size=5>Vehicle Query</font></a>
    <br>
    <br>
    <a href="Insertverify_add_new_car.php"><font size=5>Add Vehicle information</font></a>
    <br>
    <br>
    <a href="report.php"><font size=5>Reporting</font></a>


</main>
</body>
</html>

