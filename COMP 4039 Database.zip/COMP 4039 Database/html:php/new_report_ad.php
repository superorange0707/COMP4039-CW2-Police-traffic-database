<html>
<head>
    <title>Add New Report</title>
    <link rel="stylesheet" href="mvp.css">
</head>
<body>
<main>
    <h1>Add New Report</h1>
    <h2>Report details</u></h2>

    <form  method="post">
        Vehicle licence: <input type="text" name="vehicle_licence"><br/>
        Incident Date: <input type="date" name="time"><br/>
        Incident Report: <input type="text" name="report"><br/>
        Offence ID: <input type="text" name="Offence_ID"><br/>

        <input type="submit" value="add">
    </form>

    <?php
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $servername = "mysql.cs.nott.ac.uk";
    $username = "psxjj4_psxjj4_1";
    $password = "WKXLHX";
    $dbname = "psxjj4_psxjj4_1"; 

    if (isset($_POST['vehicle_licence']))
    {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
        }
        $vehicle_licence = $_POST['vehicle_licence'];
        $time = $_POST['time'];
        $report = $_POST['report'];
        $Offence_ID = $_POST['Offence_ID'];
        $sql = "SELECT * FROM Vehicle WHERE Vehicle_licence = '$vehicle_licence';" ;
        $result = mysqli_query($conn, $sql);
//        check the vehicle is in the system or not
        if (mysqli_num_rows($result) <= 0){
            echo "<script>alert('the vehicle is not in the system')</script>";
            echo "<meta http-equiv='Refresh' content='0;URL=Insertverify_admin.php'>";
        }
        else{
            $check = "SELECT * FROM (Vehicle LEfT JOIN Ownership on Vehicle.Vehicle_ID = Ownership.Vehicle_ID) WHERE upper(Vehicle_licence) = upper('$vehicle_licence');" ;
            $result_id = mysqli_query($conn, $check);
            $row = mysqli_fetch_assoc($result_id);
//            get vehicle_id and people_id
            $Vehicle_id = $row["Vehicle_ID"];
            $people_id = $row["People_ID"];
            $add_report = "INSERT INTO Incident (Vehicle_ID, People_ID, Incident_Date, Incident_Report, Offence_ID) VALUES ('$Vehicle_id', '$people_id', '$time', '$report', '$Offence_ID')";
            mysqli_query($conn, $add_report);
            echo "<script>alert('The new report has been added')</script>";
        }


        mysqli_close($conn);
    }
    ?>
</main>
<footer><a href="admin.php">Back to main page</a></footer>
</body>
</html>




