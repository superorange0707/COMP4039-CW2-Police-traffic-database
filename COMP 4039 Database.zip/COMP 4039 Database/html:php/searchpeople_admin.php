<html>
<head>
    <title>Searchpeople</title>
    <link rel="stylesheet" href="mvp.css">
</head>
<body>
<main>
    <h1>Search People</h1>
    <h2>People detail</u></h2>

    <form  method="post">
        Name: <input type="text" name="name"><br/>
        Driving Licence: <input type="text" name="driving_licence">
        <input type="submit" value="Search">
    </form>

    <?php
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $servername = "mysql.cs.nott.ac.uk";
    $username = "psxjj4_psxjj4_1";
    $password = "WKXLHX";
    $dbname = "psxjj4_psxjj4_1";

    if (isset($_POST['name']))
    {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
        }
        $name = $_POST['name'];
        $driving_licence = $_POST['driving_licence'];
        $sql = "SELECT * FROM People WHERE People_name LIKE '%$name%';" ;
        $check = "SELECT * FROM People WHERE People_licence = '$driving_licence';";
        $result_name = mysqli_query($conn, $sql);
        $result_licence = mysqli_query($conn, $check);

        if ($name == NULL and $driving_licence == NULL){
            exit;
        }

        if (mysqli_num_rows($result_name) > 0) {
            while ($row = mysqli_fetch_assoc($result_name)) {
                echo 'NAME:',$row["People_name"], ' ', 'ADDRESS:',$row["People_address"], 'DRIVING LINCENCE:',$row["People_licence"];
                echo '<br>';
            }
        }
        elseif (mysqli_num_rows($result_licence) > 0){
            $row = mysqli_fetch_assoc($result_licence);
            echo 'NAME:',$row["People_name"], 'ADDRESS:',$row["People_address"], 'DRIVING LINCENCE:',$row["People_licence"];
        }
        else {
            echo "this user isn't in the system!";
        }

        mysqli_close($conn);
    }
    ?>
</main>
<footer><a href="admin.php">Back to main page</a></footer>
</body>
</html>
