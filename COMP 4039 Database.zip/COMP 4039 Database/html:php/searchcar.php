<html>
<head>
    <title>Searchcar</title>
    <link rel="stylesheet" href="mvp.css">
</head>
<body>
<main>
    <h1>Search Car</h1>
    <h2>Car detail</u></h2>

    <form  method="post">
        Vehicle_Licence: <input type="text" name="Vehicle_Licence">
        <input type="submit" value="Search">
    </form>

    <?php
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $servername = "mysql.cs.nott.ac.uk";
    $username = "psxjj4_psxjj4_1";
    $password = "WKXLHX";
    $dbname = "psxjj4_psxjj4_1"; 

    if (isset($_POST['Vehicle_Licence']))
    {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
        }
//获取车牌号
        $Vehicle_licence = $_POST['Vehicle_Licence'];
//         Left join union query of ownership and vehicle tables to get all information
        $sql = "SELECT * FROM (Vehicle LEfT JOIN Ownership on Vehicle.Vehicle_ID = Ownership.Vehicle_ID) WHERE upper(Vehicle_licence) = upper('$Vehicle_licence');" ;
        $result_name = mysqli_query($conn, $sql);

//        判断车辆是否存在
        if (mysqli_num_rows($result_name) > 0) {
            $row = mysqli_fetch_assoc($result_name);
            $people = $row["People_ID"];
//            如果车辆主人数据存在
            if ($row["People_ID"] > 0){
//                left join the PEOPLE table and the OWNERSHIP table to get the owner's name
                $people_name = "SELECT People_name FROM People WHERE People_ID = '$people';" ;
                $result_people1 = mysqli_query($conn, $people_name);
                $row1 = mysqli_fetch_assoc($result_people1);
                echo $row1["People_name"];
                echo '<br>';
                echo $row["Vehicle_type"];
                echo '<br>';
                echo $row["Vehicle_colour"];
                echo '<br>';
                echo $row["Vehicle_licence"];
            }
//            如果主人数据不存在
            else{
                echo "no owner recorded in the system";
                echo '<br>';
                echo $row["Vehicle_type"];
                echo '<br>';
                echo $row["Vehicle_colour"];
                echo '<br>';
                echo $row["Vehicle_licence"];
            }
        }
        else {
            echo "this car isn't in the system!";
        }
        mysqli_close($conn);
    }
    ?>
</main>
<footer><a href="index.php">Back to main page</a></footer>
</body>
</html>




