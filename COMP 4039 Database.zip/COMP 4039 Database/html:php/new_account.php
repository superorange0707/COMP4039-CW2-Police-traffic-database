<html>
<head>
    <title>Add New Car</title>
    <link rel="stylesheet" href="mvp.css">
    <script>
        function validateForm() {
            var x = document.forms["myForm"]["name"].value; // see https://www.w3schools.com/js/js_validation.asp

            if (x == "") {
                alert("All informations must be filled out");
                return false;
            }
            var y = document.forms["myForm"]["password"].value;
            if (y == "") {
                alert("All informations must be filled out");
                return false;

            }
            var z = document.forms["myForm"]["password_confirm"].value;
            if (z == "") {
                alert("All informations must be filled out");
                return false;

            }
        }
    </script>
</head>
<body>
<main>
    <h1>Creat New account</h1>
    <h2>New account details</u></h2>

    <form  name="myForm" method="post" onsubmit="return validateForm()">
        Username: <input type="text" name="name"><br/>
        password: <input type="text" name="password"><br/>
        password_confirm: <input type="text" name="password_confirm">
        <input type="submit" value="create">
    </form>

    <?php
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $servername = "mysql.cs.nott.ac.uk";
    $username = "psxjj4_psxjj4_1";
    $password = "WKXLHX";
    $dbname = "psxjj4_psxjj4_1"; 

    if (isset($_POST['name']))
    {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
        }
        $name = $_POST['name'];
        $password = $_POST['password'];
        $password_confirm = $_POST['password_confirm'];
        $sql = "SELECT * FROM userlogin;" ;
        $result = mysqli_query($conn, $sql);

//        username should be appeared once
        while ($row = mysqli_fetch_assoc($result)) {
            $exists_username = $row["Username"];
            if ($name == $exists_username) {
                echo "<script>alert('this username has been used in the system')</script>";
                exit;
            }
        }

//        check the password
        if ($password != $password_confirm){
            echo "<script>alert('input the same new password')</script>";
        }
        else{
            //      add person
            $add_person = "INSERT INTO userlogin (Username, Password) VALUES ('$name', '$password')";
            mysqli_query($conn, $add_person);
            echo "<script>alert('The new account has been created')</script>";
            }
        mysqli_close($conn);
    }
    ?>
</main>
<footer><a href="admin.php">Back to main page</a></footer>
</body>
</html>




