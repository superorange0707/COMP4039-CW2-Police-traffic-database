<html>
<head>
		<title>Login_page</title>
		<link rel="stylesheet" href="mvp.css">
	</head>
<body>
<main>
  <h1>WELCOME</h1>
  <h2>Police System</h2>

  <form  method="post">
        Username: <input type="text" name="name"><br/>
        Password: <input type="text" name="password"><br/>
      <input type="submit" value="Login">
  </form>

  <?php
       error_reporting(E_ALL);
       ini_set('display_errors',1);
       $servername = "mysql.cs.nott.ac.uk";
       $username = "psxjj4_psxjj4_1";
       $password = "WKXLHX";
       $dbname = "psxjj4_psxjj4_1";
       session_start();
       if (isset($_POST['name']))
       {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
         }
            $name = $_POST['name'];
            $userpassword = $_POST['password'];
            $sql = "SELECT * FROM userlogin WHERE Username LIKE \"%". $name . "%\";" ;
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $correct_username = $row["Username"];
                $correct_password = $row["Password"];
                if($name ==$correct_username and $userpassword == $correct_password){
//                        admin
                    if($name == "Daniels")
                    {
                        header("location: admin.php");
                        $_SESSION['user'] = $_POST['name'];
                    }
//                        user
                    else{
                        header("location: index.php");
                        $_SESSION['user'] = $_POST['name'];
                    }
                }
                else{
                    echo "your password is wrong";
                }
           }
           else {
             echo "this user isn't in the system!";
           }

           mysqli_close($conn);
       }
  ?>
</main>
</body>
</html>