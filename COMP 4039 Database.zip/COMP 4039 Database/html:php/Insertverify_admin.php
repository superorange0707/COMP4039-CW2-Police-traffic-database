<html>
<head>
    <title>Add New Car</title>
    <link rel="stylesheet" href="mvp.css">
    <script>
        function validateForm()
        {
            var x = document.forms["myForm"]["vehicle_licence"].value; // see https://www.w3schools.com/js/js_validation.asp

            if (x == "") {
                alert("All informations must be filled out");
                return false;
            }
            var y = document.forms["myForm"]["vehicle_colour"].value;
            if (y == "") {
                alert("All informations must be filled out");
                return false;

            }
            var z = document.forms["myForm"]["vehicle_type"].value;
            if (z == "") {
                alert("All informations must be filled out");
                return false;

            }
            var a = document.forms["myForm"]["name"].value;
            if (a == "") {
                alert("All informations must be filled out");
                return false;

            }
            var b = document.forms["myForm"]["driving_licence"].value;
            if (b == "") {
                alert("All informations must be filled out");
                return false;

            }
        }
    </script>
</head>
<body>
<main>
    <h1>Add New Car</h1>
    <h2>New car detail</u></h2>

    <form  name="myForm" method="post" onsubmit="return validateForm()">
        Vehicle Licence: <input type="text" name="vehicle_licence"><br/>
        Vehicle Colour: <input type="text" name="vehicle_colour"><br/>
        Vehicle Type: <input type="text" name="vehicle_type"><br/>
        Name of Owner: <input type="text" name="name"><br/>
        People Licence: <input type="text" name="driving_licence">
        <input type="submit" value="Add">
    </form>

    <?php
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $servername = "mysql.cs.nott.ac.uk";
    $username = "psxjj4_psxjj4_1";
    $password = "WKXLHX";
    $dbname = "psxjj4_psxjj4_1"; 
    session_start();

    if (isset($_POST['vehicle_licence']))
    {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
        }

        $vehicle_licence = $_POST['vehicle_licence'];
        $vehicle_colour = $_POST['vehicle_colour'];
        $vehicle_type = $_POST['vehicle_type'];
        $name = $_POST['name'];
        $driving_licence = $_POST['driving_licence'];
        $check = "SELECT * FROM People WHERE upper(People_licence) = upper('$driving_licence');";
        $result_licence = mysqli_query($conn, $check);

//verify the owner exists in the system or not
        if (mysqli_num_rows($result_licence) > 0){
            $row = mysqli_fetch_assoc($result_licence);
//            get the owner_people id
            $people_id = $row["People_ID"];

//            add new car detail to the vehicle table
            $sql = "INSERT INTO Vehicle (Vehicle_licence, Vehicle_colour, Vehicle_type) VALUES ('$vehicle_licence', '$vehicle_colour', '$vehicle_type')";
            mysqli_query($conn, $sql);

//           get the vehicle id
            $search_id = "SELECT * FROM Vehicle WHERE Vehicle_licence = '$vehicle_licence';" ;
            $result_id = mysqli_query($conn, $search_id);
            $row1 = mysqli_fetch_assoc($result_id);
            $vehicle_id = $row1["Vehicle_ID"];

//           add ownership of vehicle
            $ownership = "INSERT INTO Ownership (People_ID, Vehicle_ID) VALUES ('$people_id', '$vehicle_id')";
            mysqli_query($conn,$ownership);
            echo "<script>alert('The detail of new car has been added')</script>";

        }
        else {
            echo "<script>alert('the owner is not in the system')</script>";
            echo "<meta http-equiv='Refresh' content='0;URL=insert_ad.php'>";
            $_SESSION['vehicle_licence'] = $_POST['vehicle_licence'];
            $_SESSION['vehicle_colour'] = $_POST['vehicle_colour'];
            $_SESSION['vehicle_type'] = $_POST['vehicle_type'];
        }

        mysqli_close($conn);
    }
    ?>
</main>
<footer><a href="admin.php">Back to main page</a></footer>
</body>
</html>
