<html>
<head>
    <title>Login_page</title>
    <link rel="stylesheet" href="mvp.css">
    <script>
        function validateForm() {
            var x = document.forms["myForm"]["new_password1"].value; // see https://www.w3schools.com/js/js_validation.asp

            if (x == "") {
                alert("All informations must be filled out");
                return false;
            }
            var y = document.forms["myForm"]["new_password2"].value;
            if (y == "") {
                alert("All informations must be filled out");
                return false;

            }
        }
    </script>
</head>
<body>
<main>
    <h1>Change Password</h1>
    <h2>Change password</h2>

    <form  name="myForm" method="post" onsubmit="return validateForm()">
        New password: <input type="text" name="new_password1"><br/>
        Confirm New Password: <input type="text" name="new_password2"><br/>
        <input type="submit" value="Change">
    </form>

    <?php
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $servername = "mysql.cs.nott.ac.uk";
    $username = "psxjj4_psxjj4_1";
    $password = "WKXLHX";
    $dbname = "psxjj4_psxjj4_1";
    session_start();

    $current_user = $_SESSION['user'];

    if (isset($_POST['new_password1']))
    {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
        }
        $new_password1 = $_POST['new_password1'];
        $new_password2 = $_POST['new_password2'];
        if ($new_password1 != $new_password2){
            echo "<script>alert('input the same new password')</script>";
        }
        else{
            $sql = "UPDATE userlogin SET Password='$new_password1' where Username='$current_user'";
            echo "<script>alert('The password of current user has been changed')</script>";
            mysqli_query($conn,$sql);
        }
        mysqli_close($conn);
    }
    ?>
</main>
<footer><a href="admin.php">Back to main page</a></footer>
</body>
</html>