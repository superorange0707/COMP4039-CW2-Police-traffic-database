<html>
<head>
    <title>Add New Car</title>
    <link rel="stylesheet" href="mvp.css">
</head>
<body>
<main>
    <h1>Add New Car</h1>
    <h2>New car detail</u></h2>

    <form  method="post">
<!--        Vehicle Licence: <input type="text" name="vehicle_licence"><br/>-->
<!--        Vehicle Colour: <input type="text" name="vehicle_colour"><br/>-->
<!--        Vehicle Type: <input type="text" name="vehicle_type"><br/>-->
        Name of Owner: <input type="text" name="name"><br/>
        Address: <input type="text" name="address"><br/>
        Driving Licence: <input type="text" name="driving_licence">
        <input type="submit" value="Add">
    </form>

    <?php
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $servername = "localhost";
    $username = "root";
    $password = "201514jia";
    $dbname = "dis";
    session_start();

    if (isset($_POST['name']))
    {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
        }

        $vehicle_licence = $_SESSION['vehicle_licence'];
        $vehicle_colour = $_SESSION['vehicle_colour'];
        $vehicle_type = $_SESSION['vehicle_type'];
        $name = $_POST['name'];
        $address = $_POST['address'];
        $driving_licence = $_POST['driving_licence'];
//      add person
        $add_person = "INSERT INTO People (People_name, People_address, People_licence) VALUES ('$name', '$address', '$driving_licence')";
        mysqli_query($conn, $add_person);

//        get the people id
        $check = "SELECT * FROM People WHERE upper(People_licence) = upper('$driving_licence');";
        $result_licence = mysqli_query($conn, $check);

//verify the owner exists in the system or not
        if (mysqli_num_rows($result_licence) > 0){
            $row = mysqli_fetch_assoc($result_licence);
//            get the owner_people id
            $people_id = $row["People_ID"];

//            add new car detail to the vehicle table
            $sql = "INSERT INTO Vehicle (Vehicle_licence, Vehicle_colour, Vehicle_type) VALUES ('$vehicle_licence', '$vehicle_colour', '$vehicle_type')";
            mysqli_query($conn, $sql);

//           get the vehicle id
            $search_id = "SELECT * FROM Vehicle WHERE Vehicle_licence = '$vehicle_licence';" ;
            $result_id = mysqli_query($conn, $search_id);
            $row1 = mysqli_fetch_assoc($result_id);
            $vehicle_id = $row1["Vehicle_ID"];

//           add ownership of vehicle
            $ownership = "INSERT INTO Ownership (People_ID, Vehicle_ID) VALUES ('$people_id', '$vehicle_id')";
            mysqli_query($conn,$ownership);
            echo "<script>alert('The detail of new car has been added')</script>";
            echo "<meta http-equiv='Refresh' content='0;URL=insertverify.php'>";

        }
        else {
            echo "<script>alert('the owner is not in the system')</script>";
            echo "<meta http-equiv='Refresh' content='0;URL=insert.php'>";
            $_SESSION['vehicle_licence'] = $_POST['vehicle_licence'];
            $_SESSION['vehicle_colour'] = $_POST['vehicle_colour'];
            $_SESSION['vehicle_type'] = $_POST['vehicle_type'];
        }

        mysqli_close($conn);
    }
    ?>
</main>
<footer><a href="index.php">Back to main page</a></footer>
</body>
</html>




