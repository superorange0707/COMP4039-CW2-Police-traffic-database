<html>
<head>
    <title>Searchpeople</title>
    <link rel="stylesheet" href="mvp.css">
</head>
<body>
<main>
    <h1>Search People</h1>
    <h2>People detail</u></h2>

    <form  method="post">
        Incident ID: <input type="text" name="incident_id">
        <input type="submit" value="Search">
    </form>

    <?php
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $servername = "localhost";
    $username = "root";
    $password = "201514jia";
    $dbname = "dis";

    if (isset($_POST['name']))
    {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
        }
        $name = $_POST['name'];
        $driving_licence = $_POST['driving_licence'];
        $sql = "SELECT * FROM People WHERE upper(People_name) = upper('$name');" ;
        $check = "SELECT * FROM People WHERE upper(People_licence) = upper('$driving_licence');";
        $result_name = mysqli_query($conn, $sql);
        $result_licence = mysqli_query($conn, $check);


        if (mysqli_num_rows($result_name) > 0) {
            while ($row = mysqli_fetch_assoc($result_name)) {
                echo 'NAME:',$row["People_name"], 'ADDRESS:',$row["People_address"], 'DRIVING LINCENCE:',$row["People_licence"];
                echo '<br>';
            }
        }
        elseif (mysqli_num_rows($result_licence) > 0){
            $row = mysqli_fetch_assoc($result_licence);
            echo 'NAME:',$row["People_name"], 'ADDRESS:',$row["People_address"], 'DRIVING LINCENCE:',$row["People_licence"];
        }
        else {
            echo "this user isn't in the system!";
        }

        mysqli_close($conn);
    }
    ?>
</main>
<footer><a href="index.php">Back to main page</a></footer>
</body>
</html>




