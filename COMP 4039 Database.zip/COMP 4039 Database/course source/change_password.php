<html>
<head>
    <title>Login_page</title>
    <link rel="stylesheet" href="mvp.css">
</head>
<body>
<main>
    <h1>Change Password</h1>
    <h2>Change password</h2>

    <form  method="post">
        New password: <input type="text" name="new_password1"><br/>
        Confirm New Password: <input type="text" name="new_password2"><br/>
        <input type="submit" value="Change">
    </form>

    <?php
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $servername = "localhost";
    $username = "root";
    $password = "201514jia";
    $dbname = "dis";
    session_start();

    $current_user = $_SESSION['user'];

    if (isset($_POST['new_password1']))
    {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
        }
        $new_password1 = $_POST['new_password1'];
        $new_password2 = $_POST['new_password2'];
        if ($new_password1 != $new_password2){
            echo "<script>alert('input the same new password')</script>";
        }
        else{
            $sql = "UPDATE userlogin SET Password='$new_password1' where Username='$current_user'";
            echo "<script>alert('The password of current user has been changed')</script>";
            mysqli_query($conn,$sql);
        }
        mysqli_close($conn);
    }
    ?>
</main>
<footer><a href="index.php">Back to main page</a></footer>
</body>
</html>