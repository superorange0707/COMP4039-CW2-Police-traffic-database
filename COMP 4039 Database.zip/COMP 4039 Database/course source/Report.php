<html>
<head>
    <title>INTERNAL POLICE SYSTEM</title>
    <link rel="stylesheet" href="mvp.css">
</head>
<body>
<main>
    <h1>Report System</h1>

    <a href="search_report.php"><font size=5>Search Report</font></a>
    <br>
    <br>
    <a href="new_report.php"><font size=5>New Report</font></a>
    <br>
    <br>
    <a href="edit_report.php"><font size=5>Edit Report</font></a>

</main>
</body>
</html>

