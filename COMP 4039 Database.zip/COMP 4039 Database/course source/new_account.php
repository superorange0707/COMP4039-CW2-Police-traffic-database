<html>
<head>
    <title>Add New Car</title>
    <link rel="stylesheet" href="mvp.css">
</head>
<body>
<main>
    <h1>Creat New account</h1>
    <h2>New account details</u></h2>

    <form  method="post">
        Username: <input type="text" name="name"><br/>
        password: <input type="text" name="password"><br/>
        password_confirm: <input type="text" name="password_confirm">
        <input type="submit" value="create">
    </form>

    <?php
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $servername = "localhost";
    $username = "root";
    $password = "201514jia";
    $dbname = "dis";

    if (isset($_POST['name']))
    {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
        }
        $name = $_POST['name'];
        $password = $_POST['password'];
        $password_confirm = $_POST['password_confirm'];
        $sql = "SELECT * FROM userlogin;" ;
        $result = mysqli_query($conn, $sql);

//        username should be appeared once
        while ($row = mysqli_fetch_assoc($result)) {
            $exists_username = $row["Username"];
            if ($name == $exists_username) {
                echo "<script>alert('this username has been used in the system')</script>";
                exit;
            }
        }

//        check the password
        if ($password != $password_confirm){
            echo "<script>alert('input the same new password')</script>";
        }
        else{
            //      add person
            $add_person = "INSERT INTO userlogin (Username, Password) VALUES ('$name', '$password')";
            mysqli_query($conn, $add_person);
            echo "<script>alert('The new account has been created')</script>";
            }
        mysqli_close($conn);
    }
    ?>
</main>
<footer><a href="admin.php">Back to main page</a></footer>
</body>
</html>




