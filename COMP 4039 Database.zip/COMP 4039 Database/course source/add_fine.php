<html>
<head>
    <title>Add New Fine</title>
    <link rel="stylesheet" href="mvp.css">
</head>
<body>
<main>
    <h1>Add New fine</h1>
    <h2>Fine details</u></h2>

    <form  method="post">
        Fine Amount: <input type="text" name="amount"><br/>
        Fine Points: <input type="text" name="points"><br/>
        Incident ID: <input type="text" name="incident_id">
        <input type="submit" value="add">
    </form>

    <?php
    error_reporting(E_ALL);
    ini_set('display_errors',1);
    $servername = "localhost";
    $username = "root";
    $password = "201514jia";
    $dbname = "dis";

    if (isset($_POST['amount']))
    {
        $conn = mysqli_connect($servername, $username, $password, $dbname);
        if(!$conn) {
            die ("Connection failed");
        }
        $fine_amount = $_POST['amount'];
        $fine_points = $_POST['points'];
        $incident_id = $_POST['incident_id'];
        $sql = "SELECT * FROM Incident WHERE Incident_ID = '$incident_id';" ;
        $result = mysqli_query($conn, $sql);

        //check the incident in the system
        if (mysqli_num_rows($result) <= 0) {
            echo "<script>alert('There is no incident with this number in the system')</script>";
        }
        else{
                $check = "SELECT * FROM Fines WHERE Incident_ID = '$incident_id';";
                $result_check = mysqli_query($conn, $check);
//            the incident has been fined in the system
            if (mysqli_num_rows($result_check) > 0){
                echo "<script>alert('There is a fine with this incident in the system')</script>";
            }
//            add new fine
            else{
                $add_person = "INSERT INTO Fines (Fine_Amount, Fine_Points, Incident_ID) VALUES ('$fine_amount', '$fine_points', '$incident_id')";
                mysqli_query($conn, $add_person);
                echo "<script>alert('The new fine has been added')</script>";
            }
        }

        mysqli_close($conn);
    }
    ?>
</main>
<footer><a href="admin.php">Back to main page</a></footer>
</body>
</html>




